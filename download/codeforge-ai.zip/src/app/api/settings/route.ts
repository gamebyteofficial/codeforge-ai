import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { testProviderConnection, getApiKeyForProvider, type ProviderKey } from '@/lib/llm';

export async function GET() {
  try {
    const settings = await db.setting.findMany();
    const settingsMap: Record<string, string> = {};
    settings.forEach((s) => {
      settingsMap[s.key] = s.value;
    });
    return NextResponse.json({ settings: settingsMap });
  } catch (error) {
    console.error('Failed to fetch settings:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { settings, testConnection } = body as {
      settings: Record<string, string>;
      testConnection?: boolean;
    };

    if (!settings) {
      return NextResponse.json({ error: 'Settings object is required' }, { status: 400 });
    }

    // Handle real connection test
    if (testConnection) {
      const provider = (settings.provider || 'openai') as ProviderKey;

      // Try per-provider key first, then legacy key
      const apiKey = getApiKeyForProvider(settings, provider) || settings.apiKey;

      if (!apiKey) {
        return NextResponse.json(
          { success: false, error: 'API key is required to test connection' },
          { status: 400 },
        );
      }

      const result = await testProviderConnection(provider, apiKey);

      if (result.success) {
        return NextResponse.json({
          success: true,
          provider,
          message: `Successfully connected to ${provider}`,
        });
      } else {
        return NextResponse.json({
          success: false,
          error: result.error || 'Connection failed',
        });
      }
    }

    // Save settings
    const operations = Object.entries(settings).map(([key, value]) =>
      db.setting.upsert({
        where: { key },
        update: { value },
        create: { key, value },
      })
    );

    await Promise.all(operations);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to save settings:', error);
    return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 });
  }
}
